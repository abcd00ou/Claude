---
name: Supply Chain Optimization
description: >
  USE THIS SKILL when the user asks about supply chain strategy, network design, inventory
  optimization, demand planning, S&OP, logistics, distribution, warehousing, transportation,
  last-mile delivery, supplier management, lead times, safety stock, EOQ, ABC analysis,
  XYZ analysis, supply chain risk, total cost of ownership, or supply chain maturity.
  Also trigger for questions about fulfillment strategy, order-to-delivery cycle,
  supply chain resilience, nearshoring, reshoring, or multi-echelon inventory.
---

# Supply Chain Optimization

## Required Inputs

| Input | Description | Required? |
|-------|-------------|-----------|
| Supply chain scope | Which nodes to analyze (supplier, manufacturing, distribution, last mile, or all) | Yes |
| Product / SKU data | Product portfolio, volume, value, demand variability | Yes |
| Current network map | Locations of suppliers, plants, DCs, customers | Yes |
| Cost data | Procurement, manufacturing, logistics, warehousing, inventory carrying costs | Yes |
| Service level targets | Fill rates, on-time delivery, lead time commitments | Yes |
| Demand data | Historical demand (24+ months preferred), seasonality, trends | Recommended |
| Supplier information | Lead times, MOQs, reliability, geographic locations | Recommended |
| Strategic context | Growth plans, M&A, market expansion, channel shifts | Recommended |

## Execution Steps

### Step 1: Supply Chain Maturity Assessment

Score across 8 dimensions on a 1-5 scale:

| Dimension | 1 - Reactive | 2 - Functional | 3 - Integrated | 4 - Collaborative | 5 - Orchestrated |
|-----------|-------------|---------------|----------------|-------------------|-----------------|
| **Demand Planning** | No forecasting; order-driven only | Basic statistical forecasting | Demand sensing with multiple inputs | Collaborative forecasting with customers | AI-driven demand shaping |
| **Inventory Mgmt** | No formal policy; gut-feel ordering | Reorder point / EOQ basics | ABC segmentation; safety stock calc | Multi-echelon optimization | Dynamic, demand-driven positioning |
| **Sourcing** | Single source; price-only decisions | Approved vendor lists; RFQ process | Category management; TCO analysis | Strategic partnerships; joint planning | Supplier ecosystem orchestration |
| **Manufacturing** | Build to stock; long runs | Basic scheduling; some flexibility | Pull-based; mixed-model capability | Demand-driven; postponement | Agile / mass customization |
| **Logistics** | Reactive shipping; no carrier mgmt | Rate shopping; basic TMS | Optimized routing; mode selection | Integrated logistics network | Autonomous / real-time optimization |
| **Visibility** | No end-to-end visibility | Visibility within functional silos | Cross-functional dashboards | Multi-tier supply chain visibility | Predictive / prescriptive analytics |
| **Risk Management** | No risk assessment | Basic risk register | Scenario planning; dual sourcing | Continuous monitoring; response plans | Predictive risk management |
| **Sustainability** | No sustainability focus | Compliance-driven only | Scope 1-2 emissions tracked | Full Scope 3 measurement; targets set | Circular supply chain; net-zero path |

**Overall Maturity** = Average score. Prioritize dimensions with scores below 3.

### Step 2: Network Design Analysis

Map the current supply chain network and evaluate:

**Network Structure Assessment:**

| Element | Current State | Benchmark / Best Practice | Gap |
|---------|--------------|--------------------------|-----|
| Number of suppliers (Tier 1) | | | |
| Number of manufacturing sites | | | |
| Number of distribution centers | | | |
| Average distance to customer | | | |
| Number of echelons | | | |
| % single-sourced SKUs | | | |
| Geographic concentration risk | | | |

**Network Cost Breakdown:**

| Cost Category | Annual Cost ($) | % of Revenue | % of Total SC Cost | Benchmark |
|--------------|----------------|-------------|-------------------|-----------|
| Raw materials / COGS | | | | |
| Inbound freight | | | | |
| Manufacturing / conversion | | | | |
| Warehousing / DC operations | | | | |
| Outbound freight | | | | |
| Last-mile delivery | | | | |
| Inventory carrying cost | | | | |
| Customs / duties / tariffs | | | | |
| **Total Supply Chain Cost** | | | | |

**Network Optimization Levers:**
1. Facility consolidation / rationalization
2. Geographic repositioning (nearshoring, reshoring)
3. Multi-echelon inventory repositioning
4. Transportation mode shifts
5. Channel-specific fulfillment strategies

### Step 3: Inventory Optimization

#### ABC/XYZ Classification

Classify all SKUs on two dimensions:

**ABC (Value):**
- A: Top 80% of revenue (typically 15-20% of SKUs)
- B: Next 15% of revenue (typically 25-30% of SKUs)
- C: Bottom 5% of revenue (typically 50-60% of SKUs)

**XYZ (Demand Variability — Coefficient of Variation):**
- X: CV < 0.5 — Stable, predictable demand
- Y: CV 0.5-1.0 — Variable demand with trends/seasonality
- Z: CV > 1.0 — Highly erratic, unpredictable demand

**Combined Matrix — Inventory Strategy:**

| | X (Stable) | Y (Variable) | Z (Erratic) |
|---|-----------|-------------|-------------|
| **A (High Value)** | Lean flow; JIT; low safety stock | Demand-driven; moderate safety stock | Strategic buffer; vendor-managed |
| **B (Medium Value)** | Kanban; reorder point | Periodic review; seasonal build | Make-to-order where possible |
| **C (Low Value)** | Bulk order; maximize efficiency | Periodic review; accept stockouts | Eliminate or special-order only |

#### Safety Stock Calculation

For each SKU segment:

```
Safety Stock = Z-score x sqrt(LT x Demand_Variance + Demand_Avg^2 x LT_Variance)

Where:
  Z-score = Service level factor (95% = 1.65, 97% = 1.88, 99% = 2.33)
  LT = Average lead time (in periods)
  Demand_Variance = Variance of demand per period
  Demand_Avg = Average demand per period
  LT_Variance = Variance of lead time (in periods)
```

#### EOQ with Total Cost

```
EOQ = sqrt(2 x D x S / H)

Where:
  D = Annual demand (units)
  S = Fixed ordering cost per order ($)
  H = Annual holding cost per unit ($) = Unit cost x Carrying cost %

Total Annual Inventory Cost = (D/Q x S) + (Q/2 x H) + (Safety Stock x H)
```

Calculate optimal inventory investment and compare to current state.

### Step 4: Demand Planning & S&OP Assessment

**Demand Planning Effectiveness:**

| Metric | Current | Target | Gap |
|--------|---------|--------|-----|
| Forecast accuracy (MAPE) | | < 20% (A items) | |
| Forecast bias | | < 5% | |
| Forecast horizon | | 12-18 months rolling | |
| Forecast granularity | | SKU x Location x Week | |
| Demand sensing lag | | < 1 week | |

**S&OP Process Maturity:**

| Element | Current Practice | Target Practice |
|---------|-----------------|-----------------|
| Meeting cadence | | Monthly minimum |
| Participants | | Cross-functional: Sales, Ops, Finance, Supply Chain |
| Planning horizon | | 18-24 months rolling |
| Scenario planning | | 3 scenarios (base, upside, downside) |
| Financial integration | | P&L impact quantified for each scenario |
| Decision authority | | Clear escalation; executive sign-off |
| KPI tracking | | Forecast accuracy, plan adherence, bias |

### Step 5: Supply Chain Risk Assessment

Evaluate risk across 5 categories:

| Risk Category | Risk Factor | Probability (1-5) | Impact (1-5) | Risk Score | Mitigation |
|--------------|------------|-------------------|-------------|------------|------------|
| **Supplier** | Single-source dependency | | | P x I | |
| **Supplier** | Financial viability of key suppliers | | | | |
| **Supplier** | Geographic concentration | | | | |
| **Operational** | Capacity constraints | | | | |
| **Operational** | Quality failures | | | | |
| **Logistics** | Transportation disruption | | | | |
| **Logistics** | Port / border congestion | | | | |
| **Demand** | Demand volatility / bullwhip | | | | |
| **External** | Geopolitical / trade policy | | | | |
| **External** | Natural disaster / pandemic | | | | |

**Risk Score Interpretation:**
- 20-25: Critical — Immediate action required; executive visibility
- 12-19: High — Mitigation plan within 30 days
- 6-11: Medium — Monitor quarterly; contingency plan in place
- 1-5: Low — Annual review

### Step 6: Total Cost of Ownership (TCO) Analysis

Calculate TCO for each major supply chain node / sourcing option:

| Cost Element | Current ($) | Alternative 1 ($) | Alternative 2 ($) |
|-------------|------------|-------------------|-------------------|
| **Acquisition Costs** | | | |
| Unit price / COGS | | | |
| Freight / inbound logistics | | | |
| Customs / duties / tariffs | | | |
| **Ownership Costs** | | | |
| Inventory carrying cost | | | |
| Warehousing / handling | | | |
| Quality / inspection costs | | | |
| **Operating Costs** | | | |
| Outbound logistics | | | |
| Returns / reverse logistics | | | |
| Stockout cost (lost sales) | | | |
| **Risk Costs** | | | |
| Supply disruption (expected value) | | | |
| Currency / commodity hedging | | | |
| Compliance / regulatory | | | |
| **Total Cost of Ownership** | **$[X]** | **$[X]** | **$[X]** |
| TCO per unit | | | |

### Step 7: Develop Optimization Recommendations

For each recommendation, specify:
1. **Description** of the change
2. **Affected nodes** in the supply chain
3. **Expected benefit** ($ and service level impact)
4. **Investment required**
5. **Implementation timeline**
6. **Risk and dependencies**
7. **ROI / payback period**

Categorize recommendations:
- **Quick wins (0-6 months):** Parameter tuning, policy changes, contract renegotiation
- **Medium-term (6-18 months):** Network changes, system implementations, process redesign
- **Strategic (18+ months):** New facilities, major technology, structural network changes

## Output Template

```markdown
# Supply Chain Optimization Assessment: [Company / Business Unit]

**Client:** [Name]
**Date:** [Date]
**Scope:** [Nodes covered: Supplier / Manufacturing / Distribution / Last Mile]

---

## 1. Executive Summary

[2-3 paragraphs: current state, key gaps, total optimization opportunity]

**Current Total Supply Chain Cost:** $[X]M ([X]% of revenue)
**Identified Savings Opportunity:** $[X]M ([X]% reduction)
**Required Investment:** $[X]M
**Service Level Impact:** [Improvement / Maintained / Trade-off described]

---

## 2. Supply Chain Maturity Assessment

| Dimension | Score (1-5) | Priority Actions |
|-----------|------------|-----------------|
| Demand Planning | | |
| Inventory Management | | |
| Sourcing | | |
| Manufacturing | | |
| Logistics | | |
| Visibility | | |
| Risk Management | | |
| Sustainability | | |
| **Overall** | **[Avg]** | |

---

## 3. Network Map Summary

### Current Network
- **Suppliers:** [X] Tier 1 across [X] countries
- **Manufacturing:** [X] plants in [locations]
- **Distribution:** [X] DCs in [locations]
- **Customer base:** [X] ship-to points; [geography]

### Network Cost Structure

| Cost Category | Annual ($M) | % of Revenue | vs. Benchmark |
|--------------|------------|-------------|---------------|
| Procurement / COGS | | | |
| Inbound logistics | | | |
| Manufacturing / conversion | | | |
| Warehousing | | | |
| Outbound logistics | | | |
| Inventory carrying | | | |
| **Total SC Cost** | **$[X]** | **[X]%** | **[+/- X pp]** |

### Network Recommendations

| # | Recommendation | Benefit ($M/yr) | Investment ($M) | Timeline |
|---|---------------|-----------------|----------------|----------|
| 1 | | | | |
| 2 | | | | |

---

## 4. Inventory Optimization

### ABC/XYZ Classification Summary

| Segment | # SKUs | % Revenue | Current Inventory ($M) | Optimal Inventory ($M) | Reduction ($M) |
|---------|--------|-----------|----------------------|----------------------|----------------|
| AX | | | | | |
| AY | | | | | |
| AZ | | | | | |
| BX | | | | | |
| BY | | | | | |
| BZ | | | | | |
| CX | | | | | |
| CY | | | | | |
| CZ | | | | | |
| **Total** | | | **$[X]** | **$[X]** | **$[X]** |

### Key Inventory Metrics

| Metric | Current | Optimized | Improvement |
|--------|---------|-----------|-------------|
| Total inventory value | $[X]M | $[X]M | -[X]% |
| Inventory turns | [X] | [X] | +[X] |
| Days of supply | [X] | [X] | -[X] days |
| Fill rate | [X]% | [X]% | +[X] pp |
| Obsolete / slow-moving | $[X]M | $[X]M | -[X]% |

---

## 5. Demand Planning & S&OP

### Current State Assessment
[Summary of demand planning maturity and S&OP gaps]

### Recommendations

| # | Recommendation | Expected Impact | Timeline |
|---|---------------|-----------------|----------|
| 1 | | | |
| 2 | | | |

---

## 6. Supply Chain Risk Heat Map

| Risk Factor | Probability | Impact | Score | Status | Mitigation |
|------------|------------|--------|-------|--------|------------|
| [Risk 1] | [1-5] | [1-5] | [P x I] | [Critical/High/Med/Low] | |
| [Risk 2] | | | | | |

### Top 3 Risk Mitigation Priorities
1. [Risk]: [Specific action plan with timeline]
2. [Risk]: [Specific action plan with timeline]
3. [Risk]: [Specific action plan with timeline]

---

## 7. Total Cost of Ownership Analysis

[TCO comparison table for key sourcing / network decisions]

---

## 8. Optimization Roadmap

### Quick Wins (0-6 Months)

| # | Initiative | Benefit ($M/yr) | Investment ($M) | Payback |
|---|-----------|-----------------|----------------|---------|
| 1 | | | | |

### Medium-Term (6-18 Months)

| # | Initiative | Benefit ($M/yr) | Investment ($M) | ROI |
|---|-----------|-----------------|----------------|-----|
| 1 | | | | |

### Strategic (18+ Months)

| # | Initiative | Benefit ($M/yr) | Investment ($M) | ROI |
|---|-----------|-----------------|----------------|-----|
| 1 | | | | |

**Total Optimization Value:** $[X]M annually
**Total Investment:** $[X]M
**Blended ROI:** [X]%

---

## 9. Recommended Next Steps

1. [Immediate action with owner and deadline]
2. [Second action]
3. [Third action]
```

## Quality Checks

- [ ] All supply chain nodes in scope are assessed — no gaps between supplier and end customer
- [ ] Inventory optimization includes both value (ABC) and variability (XYZ) dimensions
- [ ] Safety stock calculations use actual lead time variability, not just average lead time
- [ ] TCO analysis includes hidden costs (quality, risk, inventory carrying) beyond unit price
- [ ] Risk assessment covers all 5 categories with specific mitigation actions
- [ ] Network cost breakdown sums to total and percentages reconcile to revenue
- [ ] Service level impact is stated for every recommendation — no savings without trade-off transparency
- [ ] S&OP assessment evaluates process maturity, not just whether meetings happen
- [ ] Recommendations are sequenced with dependencies identified
- [ ] Inventory reduction targets are achievable without degrading fill rates below target
- [ ] Benchmarks cited are industry-specific, not generic
- [ ] Sustainability dimension is addressed, even if briefly
